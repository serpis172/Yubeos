package api

import "os"

func writeFile(path, data string) error { return os.WriteFile(path, []byte(data), 0o600) }
